// content.js can stay empty or minimal if you want to inject or interact with the page later
console.log('RBXTools content.js loaded');
