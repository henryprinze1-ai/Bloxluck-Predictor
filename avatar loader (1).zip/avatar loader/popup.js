document.addEventListener('DOMContentLoaded', () => {
  const loadBtn = document.getElementById('loadAvatarBtn');
  const avatarImg = document.getElementById('avatarImg');
  const controls = document.getElementById('controls');
  const status = document.getElementById('status');

  let currentAvatarUrl = '';
  let currentAvatarJson = '';

  function showStatus(msg, isError = false) {
    status.style.color = isError ? 'red' : 'green';
    status.textContent = msg;
  }

  async function injectContentScript(tabId) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          if (!window.robloxListenerInjected) {
            chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
              if (request.type === 'fetchUserInfo') {
                fetch('https://users.roblox.com/v1/users/authenticated', { credentials: 'include' })
                  .then(res => {
                    if (!res.ok) throw new Error('Unauthorized');
                    return res.json();
                  })
                  .then(data => sendResponse({ success: true, data }))
                  .catch(err => sendResponse({ success: false, error: err.message }));
                return true;
              }
              if (request.type === 'fetchAvatarThumbnail') {
                const userId = request.userId;
                fetch(`https://thumbnails.roblox.com/v1/users/avatar?userIds=${userId}&size=352x352&format=png&isCircular=false`, { credentials: 'include' })
                  .then(res => res.json())
                  .then(data => sendResponse({ success: true, data }))
                  .catch(err => sendResponse({ success: false, error: err.message }));
                return true;
              }
            });
            window.robloxListenerInjected = true;
          }
        }
      });
    } catch (e) {
      console.error('Failed to inject content script', e);
    }
  }

  loadBtn.addEventListener('click', async () => {
    showStatus('Loading avatar...');
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.url.includes('roblox.com')) {
      showStatus('Open a Roblox page first!', true);
      return;
    }

    await injectContentScript(tab.id);

    chrome.tabs.sendMessage(tab.id, { type: 'fetchUserInfo' }, (response) => {
      if (!response || !response.success) {
        showStatus('Failed to get user info. Please login to Roblox.', true);
        return;
      }

      const userData = response.data;
      if (!userData.id) {
        showStatus('Failed to get user ID.', true);
        return;
      }

      chrome.tabs.sendMessage(tab.id, { type: 'fetchAvatarThumbnail', userId: userData.id }, (thumbResponse) => {
        if (!thumbResponse || !thumbResponse.success || !thumbResponse.data.data || !thumbResponse.data.data[0].imageUrl) {
          showStatus('Failed to load avatar thumbnail.', true);
          return;
        }

        currentAvatarUrl = thumbResponse.data.data[0].imageUrl;
        currentAvatarJson = JSON.stringify(userData, null, 2);

        avatarImg.src = currentAvatarUrl;
        avatarImg.style.display = 'block';
        controls.style.display = 'inline-block';
        showStatus('Avatar loaded!');
      });
    });
  });

  document.getElementById('copyAvatarUrlBtn').addEventListener('click', () => {
    if (!currentAvatarUrl) return showStatus('No avatar URL to copy.', true);
    navigator.clipboard.writeText(currentAvatarUrl).then(() => showStatus('Avatar URL copied!'));
  });

  document.getElementById('copyAvatarJsonBtn').addEventListener('click', () => {
    if (!currentAvatarJson) return showStatus('No JSON to copy.', true);
    navigator.clipboard.writeText(currentAvatarJson).then(() => showStatus('Avatar JSON copied!'));
  });
});
